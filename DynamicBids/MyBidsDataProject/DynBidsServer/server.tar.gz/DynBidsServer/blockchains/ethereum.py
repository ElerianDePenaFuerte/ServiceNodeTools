# flake8: noqa: E501
import dataclasses
import requests
import time

from web3 import HTTPProvider
from web3 import Web3

from blockchains.bid import Bid


class EthBids(object):
    # eth_bids = ([Bid(fee=10000000000, execution_time=600, valid_until=1700219453), Bid(
    #    fee=8500000000, execution_time=1200, valid_until=1700219453)], 60)
    amount_gas: int = 141000

    eth_bids = ([0, 0], 0)
    gas_price = 0
    eth_price_euro = 0
    pan_price_euro = 0

    def __init__(self):
        '''
        Constructor
        '''

    def get_bids(self, dest_chain: int):
        return self.eth_bids

    def calc_bids(self):
        """ OK HOW MANY PANTOS DO I REALLY NEED:"""
        panini_price_exa_euro = self.pan_price_euro * 10000000000
        trx_price_wei = self.amount_gas * self.gas_price
        trx_price_exa_euro = trx_price_wei * self.eth_price_euro
        amount_panini = trx_price_exa_euro / panini_price_exa_euro
        amount_panini = round(amount_panini)
        print(str(amount_panini) + " PAN")
        """ OK HOW MANY PANTOS WILL WE REQUEST FROM CUSTOMER:"""
        pass
        current_unix_time = int(time.time())
        valid_until = current_unix_time + 300
        self.eth_bids = [Bid(amount_panini*3, 10, valid_until),
                         Bid(amount_panini*2, 600, valid_until),
                         Bid(round(amount_panini*1.2), 1200, valid_until)]
        # return bids
        """-------------------------------"""

    def get_data_hf(self):
        """ GET THE NEW DATA VIA API HIGH FREQUENCY!!!!!!"""
        try:
            """ GET THE GAS PRICE"""
            url = 'https://rpc.ankr.com/eth_goerli'  # url string
            url = 'https://rpc.ankr.com/eth'  # url string

            web3 = Web3(HTTPProvider(url))
            self.gas_price = web3.eth.gas_price
            print("Gas price: " + str(self.gas_price))

            """ GET THE ETH PRICE"""
            headers = {"Accept": "application/json"}
            response = requests.get(
                "https://api.onetrading.com/public/v1/market-ticker/ETH_EUR", headers=headers)
            print(response.status_code)
            response.raise_for_status()
            jsonResponse = response.json()
            self.eth_price_euro = float(jsonResponse["best_ask"])
            print("ETH: " + str(self.eth_price_euro))

            """ GET THE PAN PRICE"""
            headers = {"Accept": "application/json"}
            response = requests.get(
                "https://api.onetrading.com/public/v1/market-ticker/PAN_EUR", headers=headers)
            print(response.status_code)
            response.raise_for_status()
            jsonResponse = response.json()
            self.pan_price_euro = float(jsonResponse["best_bid"])
            print("PAN: " + str(self.pan_price_euro))

        except Exception as error:
            print(error)

    def get_data_lf(self):
        """ GET THE NEW DATA VIA API LOW FREQUENCY!!!!!!"""
        try:
            """ GET THE PANTOS PRICE"""
            headers = {"Accept": "text/plain",
                       "X-CoinAPI-Key": "853E49B6-6346-42DA-AAA0-A01017A17F56"}
            response = requests.get(
                "https://rest.coinapi.io/v1/exchangerate/PAN/EUR", headers=headers)
            print(response.status_code)
            response.raise_for_status()
            jsonResponse = response.json()
            pan_price_euro = float(jsonResponse["rate"])
            print("PAN: " + str(pan_price_euro))

        except Exception as error:
            print(error)

import dataclasses


@dataclasses.dataclass
class Bid:
    fee: int
    execution_time: int
    valid_until: int

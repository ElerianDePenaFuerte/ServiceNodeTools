# flake8: noqa: E501

import sys

from ApiProvider.Controller import Controller

if __name__ == '__main__':
    ctrl = Controller()
    ctrl.start()
